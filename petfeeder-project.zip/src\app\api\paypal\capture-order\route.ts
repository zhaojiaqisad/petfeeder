﻿import { NextResponse } from "next/server";
import { captureOrder } from "@/lib/paypal";
import prisma from "@/lib/db";

export async function POST(req: Request) {
  try {
    const { orderId, orderData } = await req.json();
    const capture = await captureOrder(orderId);

    // Save to database
    await prisma.order.create({
      data: {
        paypalOrderId: orderId,
        status: "paid",
        total: orderData.total,
        currency: orderData.currency || "USD",
        items: orderData.items || [],
        shippingAddress: orderData.shippingAddress || {},
      },
    });

    return NextResponse.json(capture);
  } catch (error) {
    console.error("PayPal capture-order error:", error);
    return NextResponse.json(
      { error: "Failed to capture PayPal order" },
      { status: 500 }
    );
  }
}
