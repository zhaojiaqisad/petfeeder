﻿import NextAuth from "next-auth";
import Credentials from "next-auth/providers/credentials";
import prisma from "./db";

export const { handlers, auth, signIn, signOut } = NextAuth({
  providers: [
    Credentials({
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials) {
        const { email, password } = credentials as { email: string; password: string };

        // For demo purposes, accept admin@petfeeder.com / admin123
        if (email === "admin@petfeeder.com" && password === "admin123") {
          return { id: "1", email: "admin@petfeeder.com", name: "Admin" };
        }

        // In production, check database
        try {
          const user = await prisma.user.findUnique({ where: { email } });
          if (user && user.password) {
            // Simple comparison for demo (use bcrypt in production)
            if (password === user.password) {
              return { id: user.id, email: user.email, name: user.name };
            }
          }
        } catch {
          // DB not available, fall through
        }

        return null;
      },
    }),
  ],
  pages: {
    signIn: "/auth/login",
  },
  session: {
    strategy: "jwt",
  },
});