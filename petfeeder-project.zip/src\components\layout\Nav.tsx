﻿"use client";

import Link from "next/link";
import { useTranslations } from "next-intl";
import CountrySwitcher from "./CountrySwitcher";
import { usePathname } from "next/navigation";

export default function Nav() {
  const t = useTranslations("nav");
  const pathname = usePathname();

  return (
    <nav className="border-b bg-white sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
        <Link href="/" className="text-xl font-bold text-blue-600">
          🐾 PetFeeder
        </Link>

        <div className="hidden md:flex items-center gap-6 text-sm">
          <Link
            href="/products"
            className={`hover:text-blue-600 transition ${pathname.startsWith("/products") ? "text-blue-600 font-medium" : "text-gray-700"}`}
          >
            {t("products")}
          </Link>
          <Link
            href="/blog"
            className={`hover:text-blue-600 transition ${pathname.startsWith("/blog") ? "text-blue-600 font-medium" : "text-gray-700"}`}
          >
            {t("blog")}
          </Link>
        </div>

        <div className="flex items-center gap-4">
          <CountrySwitcher />
          <Link href="/cart" className="text-sm hover:text-blue-600 transition text-gray-700 relative">
            🛒 <span className="hidden md:inline">{t("cart")}</span>
          </Link>
          <Link href="/account" className="text-sm hover:text-blue-600 transition text-gray-700">
            👤 <span className="hidden md:inline">{t("account")}</span>
          </Link>
        </div>
      </div>
    </nav>
  );
}
