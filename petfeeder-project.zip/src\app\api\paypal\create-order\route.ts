﻿import { NextResponse } from "next/server";
import { createOrder } from "@/lib/paypal";

export async function POST(req: Request) {
  try {
    const { amount, currency } = await req.json();
    const order = await createOrder(amount, currency);
    return NextResponse.json(order);
  } catch (error) {
    console.error("PayPal create-order error:", error);
    return NextResponse.json(
      { error: "Failed to create PayPal order" },
      { status: 500 }
    );
  }
}
