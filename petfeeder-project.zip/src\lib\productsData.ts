﻿export interface Product {
  name: string;
  slug: string;
  price: number;
  image: string;
  rating: number;
  reviewCount: number;
  description: string;
  category: 'Feeders' | 'Fountains' | 'Bowls' | 'Travel' | 'Accessories';
  specifications: { label: string; value: string }[];
}

export const products: Product[] = [
  {
    name: 'Smart Feeder Pro',
    slug: 'smart-feeder-pro',
    price: 129.99,
    image: 'https://placehold.co/600x600?text=Smart+Feeder+Pro',
    rating: 4.8,
    reviewCount: 342,
    description: 'The Smart Feeder Pro is our flagship automatic pet feeder, designed for pet owners who want total control over their pet\'s feeding schedule. With Wi-Fi connectivity, portion control, and a built-in camera, you can monitor and feed your pet from anywhere in the world. The airtight seal keeps food fresh, and the stainless steel bowl is dishwasher safe.',
    category: 'Feeders',
    specifications: [
      { label: 'Capacity', value: '5 kg' },
      { label: 'Connectivity', value: 'Wi-Fi 2.4GHz' },
      { label: 'Power', value: 'AC adapter + 4 D batteries (backup)' },
      { label: 'Camera', value: '720p HD with night vision' },
      { label: 'Portion Control', value: '1-10 portions per meal' },
      { label: 'Material', value: 'BPA-free plastic, stainless steel bowl' },
    ],
  },
  {
    name: 'Smart Feeder Lite',
    slug: 'smart-feeder-lite',
    price: 79.99,
    image: 'https://placehold.co/600x600?text=Smart+Feeder+Lite',
    rating: 4.5,
    reviewCount: 189,
    description: 'The Smart Feeder Lite offers essential smart feeding features at an affordable price. Program up to 4 meals per day with precise portion control, and schedule feeding times directly from the simple control panel. Perfect for pet owners who want reliable automatic feeding without the extra frills.',
    category: 'Feeders',
    specifications: [
      { label: 'Capacity', value: '3 kg' },
      { label: 'Connectivity', value: 'Control panel only' },
      { label: 'Power', value: 'AC adapter + 3 D batteries (backup)' },
      { label: 'Max Meals Per Day', value: '4' },
      { label: 'Portion Control', value: '1-5 portions per meal' },
      { label: 'Material', value: 'BPA-free plastic, stainless steel bowl' },
    ],
  },
  {
    name: 'Pet Water Fountain',
    slug: 'pet-water-fountain',
    price: 89.99,
    image: 'https://placehold.co/600x600?text=Pet+Water+Fountain',
    rating: 4.6,
    reviewCount: 267,
    description: 'Keep your pet hydrated with fresh, filtered water 24/7. Our Pet Water Fountain features a multi-stage filtration system that removes impurities and bad tastes, encouraging your pet to drink more. The ultra-quiet pump and large 3L capacity make it perfect for homes with multiple pets.',
    category: 'Fountains',
    specifications: [
      { label: 'Capacity', value: '3 L' },
      { label: 'Filtration', value: 'Activated carbon + foam filter' },
      { label: 'Noise Level', value: '< 25 dB' },
      { label: 'Material', value: 'BPA-free plastic' },
      { label: 'Pump Type', value: 'Submersible, ultra-quiet' },
      { label: 'Dishwasher Safe', value: 'Yes (top rack)' },
    ],
  },
  {
    name: 'Portable Travel Feeder',
    slug: 'portable-travel-feeder',
    price: 149.99,
    image: 'https://placehold.co/600x600?text=Portable+Travel+Feeder',
    rating: 4.3,
    reviewCount: 98,
    description: 'The ultimate feeding solution for pet owners on the go. This battery-powered automatic feeder features a built-in GPS tracker, scheduled dispensing, and a spill-proof design. Whether you\'re hiking, camping, or on a road trip, your pet will never miss a meal.',
    category: 'Travel',
    specifications: [
      { label: 'Capacity', value: '1.5 kg' },
      { label: 'Battery Life', value: 'Up to 30 days' },
      { label: 'GPS Tracking', value: 'Built-in with app' },
      { label: 'Weight', value: '1.2 kg' },
      { label: 'Dispenser', value: 'Spill-proof rotating mechanism' },
      { label: 'Material', value: 'Durable ABS plastic, silicone seal' },
    ],
  },
  {
    name: 'Slow Feeder Bowl',
    slug: 'slow-feeder-bowl',
    price: 34.99,
    image: 'https://placehold.co/600x600?text=Slow+Feeder+Bowl',
    rating: 4.7,
    reviewCount: 521,
    description: 'Help your pet eat at a healthier pace with our Slow Feeder Bowl. The unique maze-like interior forces your pet to work around obstacles to get their food, slowing down eating by up to 10x. Helps reduce bloating, vomiting, and obesity. Suitable for both wet and dry food.',
    category: 'Bowls',
    specifications: [
      { label: 'Diameter', value: '8 inches' },
      { label: 'Depth', value: '2.5 inches' },
      { label: 'Material', value: 'Food-grade silicone, non-slip base' },
      { label: 'Dishwasher Safe', value: 'Yes' },
      { label: 'Slow Down Factor', value: 'Up to 10x' },
      { label: 'Color Options', value: 'Blue, Green, Pink, Gray' },
    ],
  },
  {
    name: 'Stainless Steel Bowl Set',
    slug: 'stainless-bowl-set',
    price: 49.99,
    image: 'https://placehold.co/600x600?text=Stainless+Steel+Bowl+Set',
    rating: 4.4,
    reviewCount: 312,
    description: 'A premium 2-piece bowl set crafted from heavy-gauge stainless steel with a non-slip silicone base. The elevated design promotes better posture during mealtime, reducing strain on your pet\'s neck and joints. Includes a food bowl and a water bowl in a matching bamboo stand.',
    category: 'Bowls',
    specifications: [
      { label: 'Capacity (Each)', value: '2 cups / 500 ml' },
      { label: 'Material', value: '304 stainless steel, bamboo stand' },
      { label: 'Base', value: 'Non-slip silicone ring' },
      { label: 'Elevation', value: '6 inches' },
      { label: 'Dishwasher Safe', value: 'Yes (bowls only)' },
      { label: 'Set Includes', value: '1 food bowl, 1 water bowl, bamboo stand' },
    ],
  },
  {
    name: 'Replacement Filters 6-Pack',
    slug: 'replacement-filters',
    price: 24.99,
    image: 'https://placehold.co/600x600?text=Replacement+Filters',
    rating: 4.2,
    reviewCount: 156,
    description: 'Keep your Pet Water Fountain running at peak performance with our genuine replacement filter pack. Each filter combines activated carbon and a fine foam layer to remove impurities, odors, and bad tastes. Replace every 4 weeks for optimal water quality. Compatible with all PetFeeder branded water fountains.',
    category: 'Accessories',
    specifications: [
      { label: 'Pack Size', value: '6 filters' },
      { label: 'Filter Type', value: 'Activated carbon + foam' },
      { label: 'Replacement Interval', value: 'Every 4 weeks' },
      { label: 'Compatibility', value: 'All PetFeeder water fountains' },
      { label: 'Shelf Life', value: '3 years (unopened)' },
      { label: 'Material', value: 'Activated charcoal, polyurethane foam' },
    ],
  },
  {
    name: 'Elevated Feeding Station',
    slug: 'elevated-feeding-station',
    price: 79.99,
    image: 'https://placehold.co/600x600?text=Elevated+Feeding+Station',
    rating: 4.6,
    reviewCount: 203,
    description: 'Promote better digestion and posture with our Elevated Feeding Station. The sturdy bamboo frame raises bowls to a comfortable height, reducing strain on your pet\'s neck and joints. Features a spill-proof lip and an easy-clean removable tray. Suitable for medium to large breed dogs.',
    category: 'Accessories',
    specifications: [
      { label: 'Height', value: '10 inches' },
      { label: 'Material', value: 'Bamboo, stainless steel bowls' },
      { label: 'Bowl Capacity', value: '4 cups / 1 L each' },
      { label: 'Number of Bowls', value: '2' },
      { label: 'Weight Capacity', value: 'Up to 50 kg pet' },
      { label: 'Cleaning', value: 'Wipe clean frame, dishwasher safe bowls' },
    ],
  },
];

export const categories = ['All', 'Feeders', 'Fountains', 'Bowls', 'Travel', 'Accessories'] as const;

export function getProductBySlug(slug: string): Product | undefined {
  return products.find((p) => p.slug === slug);
}

export function getProductsByCategory(category: string): Product[] {
  if (category === 'All' || !category) return products;
  return products.filter((p) => p.category === category);
}
