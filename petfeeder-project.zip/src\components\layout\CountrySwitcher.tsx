﻿"use client";

import { usePathname, useRouter } from "next/navigation";

const countries = [
  { code: "en", label: "🇺🇸 United States (USD)", path: "/", currency: "USD" },
  { code: "en", label: "🇬🇧 United Kingdom (GBP)", path: "/uk", currency: "GBP" },
  { code: "de", label: "🇩🇪 Germany (EUR)", path: "/de", currency: "EUR" },
  { code: "fr", label: "🇫🇷 France (EUR)", path: "/fr", currency: "EUR" },
  { code: "en", label: "🇦🇺 Australia (AUD)", path: "/au", currency: "AUD" },
];

export default function CountrySwitcher() {
  const router = useRouter();
  const pathname = usePathname();

  const currentCountry = countries.find((c) => {
    if (c.path === "/" && pathname === "/") return true;
    if (c.path !== "/" && pathname.startsWith(c.path)) return true;
    return false;
  }) || countries[0];

  return (
    <select
      className="border rounded px-2 py-1 text-sm bg-white cursor-pointer"
      value={currentCountry.path}
      onChange={(e) => router.push(e.target.value)}
    >
      {countries.map((c) => (
        <option key={c.label} value={c.path}>
          {c.label}
        </option>
      ))}
    </select>
  );
}
