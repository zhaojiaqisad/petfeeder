﻿"use client";

import Link from "next/link";

interface ProductCardProps {
  name: string;
  slug: string;
  price: number;
  currency?: string;
  image: string;
  rating?: number;
}

export default function ProductCard({
  name,
  slug,
  price,
  currency = "USD",
  image,
  rating,
}: ProductCardProps) {
  const currencySymbol =
    currency === "USD" ? "$" :
    currency === "EUR" ? "€" :
    currency === "GBP" ? "£" :
    currency === "AUD" ? "A$" : "$";

  return (
    <Link href={`/products/${slug}`} className="group">
      <div className="aspect-square bg-gray-100 rounded-lg overflow-hidden mb-3">
        <img
          src={image}
          alt={name}
          className="object-cover w-full h-full group-hover:scale-105 transition-transform duration-300"
          loading="lazy"
        />
      </div>
      <h3 className="font-medium text-sm text-gray-900">{name}</h3>
      {rating && (
        <div className="text-yellow-400 text-xs mt-1">
          {"★".repeat(Math.floor(rating))}{"☆".repeat(5 - Math.floor(rating))}
        </div>
      )}
      <p className="text-blue-600 font-semibold mt-1">
        {currencySymbol}{price.toFixed(2)}
      </p>
    </Link>
  );
}
