﻿"use client";

import { PayPalScriptProvider, PayPalButtons } from "@paypal/react-paypal-js";

interface PayPalButtonProps {
  amount: string;
  currency?: string;
  onSuccess: (details: any) => void;
  orderData: {
    items: any[];
    total: number;
    currency: string;
    shippingAddress?: any;
  };
}

export default function PayPalButtonWrapper({
  amount,
  currency = "USD",
  onSuccess,
  orderData,
}: PayPalButtonProps) {
  const clientId = process.env.NEXT_PUBLIC_PAYPAL_CLIENT_ID;

  if (!clientId) {
    return (
      <div className="text-sm text-red-500 p-2 border border-red-200 rounded">
        PayPal not configured. Set NEXT_PUBLIC_PAYPAL_CLIENT_ID in your environment.
      </div>
    );
  }

  return (
    <PayPalScriptProvider
      options={{
        clientId,
        currency,
        intent: "capture",
      }}
    >
      <PayPalButtons
        style={{ layout: "vertical" }}
        createOrder={async () => {
          const res = await fetch("/api/paypal/create-order", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ amount, currency }),
          });
          if (!res.ok) throw new Error("Failed to create order");
          const order = await res.json();
          return order.id;
        }}
        onApprove={async (data) => {
          const res = await fetch("/api/paypal/capture-order", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              orderId: data.orderID,
              orderData,
            }),
          });
          const capture = await res.json();
          onSuccess(capture);
        }}
        onError={(err) => {
          console.error("PayPal error:", err);
        }}
      />
    </PayPalScriptProvider>
  );
}
