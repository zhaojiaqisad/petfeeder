﻿import { useTranslations } from "next-intl";
import Link from "next/link";

export default function Footer() {
  const t = useTranslations("footer");

  return (
    <footer className="bg-gray-50 border-t mt-16">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-sm">
          <div>
            <h4 className="font-semibold mb-3">🐾 PetFeeder</h4>
            <p className="text-gray-500 text-xs">Premium pet feeding products for happy, healthy pets.</p>
          </div>
          <div>
            <h4 className="font-semibold mb-3">Products</h4>
            <ul className="space-y-2 text-gray-500 text-xs">
              <li><Link href="/products" className="hover:text-blue-600">All Products</Link></li>
              <li><Link href="/products?category=Feeders" className="hover:text-blue-600">Automatic Feeders</Link></li>
              <li><Link href="/products?category=Fountains" className="hover:text-blue-600">Water Fountains</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold mb-3">Support</h4>
            <ul className="space-y-2 text-gray-500 text-xs">
              <li><Link href="/shipping" className="hover:text-blue-600">{t("shipping")}</Link></li>
              <li><Link href="/returns" className="hover:text-blue-600">{t("returns")}</Link></li>
              <li><Link href="/contact" className="hover:text-blue-600">{t("contact")}</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold mb-3">Company</h4>
            <ul className="space-y-2 text-gray-500 text-xs">
              <li><Link href="/about" className="hover:text-blue-600">{t("about")}</Link></li>
              <li><Link href="/privacy" className="hover:text-blue-600">{t("privacy")}</Link></li>
              <li><Link href="/terms" className="hover:text-blue-600">{t("terms")}</Link></li>
            </ul>
          </div>
        </div>
        <div className="border-t mt-8 pt-4 text-center text-xs text-gray-400">
          © 2026 PetFeeder. All rights reserved.
        </div>
      </div>
    </footer>
  );
}
