﻿"use client";

import { createContext, useContext, useState, useEffect, ReactNode } from "react";

export interface CartItem {
  slug: string;
  name: string;
  price: number;
  image: string;
  qty: number;
}

interface CartContextType {
  items: CartItem[];
  addItem: (item: CartItem) => void;
  removeItem: (slug: string) => void;
  updateQty: (slug: string, qty: number) => void;
  clearCart: () => void;
  total: number;
  itemCount: number;
}

const CartContext = createContext<CartContextType | null>(null);

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);

  useEffect(() => {
    const stored = localStorage.getItem("cart");
    if (stored) setItems(JSON.parse(stored));

    const handleCartUpdate = () => {
      const stored = localStorage.getItem("cart");
      if (stored) setItems(JSON.parse(stored));
    };

    window.addEventListener("cart-updated", handleCartUpdate);
    return () => window.removeEventListener("cart-updated", handleCartUpdate);
  }, []);

  const save = (newItems: CartItem[]) => {
    setItems(newItems);
    localStorage.setItem("cart", JSON.stringify(newItems));
    window.dispatchEvent(new Event("cart-updated"));
  };

  const addItem = (item: CartItem) => {
    const existing = items.find((i) => i.slug === item.slug);
    if (existing) {
      save(items.map((i) =>
        i.slug === item.slug ? { ...i, qty: i.qty + item.qty } : i
      ));
    } else {
      save([...items, item]);
    }
  };

  const removeItem = (slug: string) => save(items.filter((i) => i.slug !== slug));
  const updateQty = (slug: string, qty: number) =>
    save(items.map((i) => (i.slug === slug ? { ...i, qty } : i)));
  const clearCart = () => save([]);

  const total = items.reduce((sum, i) => sum + i.price * i.qty, 0);
  const itemCount = items.reduce((sum, i) => sum + i.qty, 0);

  return (
    <CartContext.Provider
      value={{ items, addItem, removeItem, updateQty, clearCart, total, itemCount }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (!context) throw new Error("useCart must be used within CartProvider");
  return context;
}
