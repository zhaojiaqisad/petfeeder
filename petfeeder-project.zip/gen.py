﻿import os

P = r"C:\Users\Administrator.BF-202606181836\Documents\Codex\2026-07-05\new-chat\petfeeder"
D = os.path.join(P, "src", "app", "[locale]", "admin")

BT = chr(96)  # backtick
DL = "$"

# ==================== DASHBOARD ====================
dashboard = '''import { auth } from "@/lib/auth";
import { redirect } from "next/navigation";
import Link from "next/link";

export default async function AdminDashboard() {
  const session = await auth();
  if (!session || session.user?.email !== "admin@petfeeder.com") redirect("/");

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-8 text-gray-900">''' + chr(128274) + ''' Admin Dashboard</h1>
      <div className="flex flex-col md:flex-row gap-8">
        <aside className="w-full md:w-48 flex-shrink-0">
          <nav className="flex md:flex-col gap-2">
            <Link href="/admin" className="block px-3 py-2 rounded text-sm bg-blue-50 text-blue-600 font-medium">''' + chr(128202) + ''' Dashboard</Link>
            <Link href="/admin/products" className="block px-3 py-2 rounded text-sm text-gray-600 hover:bg-gray-50">''' + chr(128230) + ''' Products</Link>
            <Link href="/admin/orders" className="block px-3 py-2 rounded text-sm text-gray-600 hover:bg-gray-50">''' + chr(128722) + ''' Orders</Link>
          </nav>
        </aside>
        <div className="flex-1">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
            <div className="bg-white border rounded-lg p-6">
              <div className="text-3xl font-bold text-blue-600">8</div>
              <div className="text-sm text-gray-500 mt-1">Products</div>
            </div>
            <div className="bg-white border rounded-lg p-6">
              <div className="text-3xl font-bold text-green-600">3</div>
              <div className="text-sm text-gray-500 mt-1">Orders</div>
            </div>
            <div className="bg-white border rounded-lg p-6">
              <div className="text-3xl font-bold text-purple-600">$479.94</div>
              <div className="text-sm text-gray-500 mt-1">Total Revenue</div>
            </div>
          </div>

          <h3 className="font-semibold mb-4 text-gray-900">Quick Links</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Link href="/admin/products" className="block p-4 border rounded-lg hover:shadow-sm transition">
              <div className="font-medium text-gray-900">''' + chr(128230) + ''' Manage Products</div>
              <div className="text-sm text-gray-500 mt-1">Add, edit, or remove products</div>
            </Link>
            <Link href="/admin/orders" className="block p-4 border rounded-lg hover:shadow-sm transition">
              <div className="font-medium text-gray-900">''' + chr(128722) + ''' Manage Orders</div>
              <div className="text-sm text-gray-500 mt-1">View and update order status</div>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
'''

# ==================== PRODUCTS ====================
# Build the tricky span line
span_class = BT + "px-2 py-0.5 rounded text-xs font-medium " + DL + "{p.isActive ? " + '"bg-green-100 text-green-700"' + " : " + '"bg-red-100 text-red-700"' + "}" + BT
products_span_line = '                      <span className={' + span_class + '}>'

products = '''import { auth } from "@/lib/auth";
import { redirect } from "next/navigation";
import Link from "next/link";

const demoProducts = [
  { name: "Smart Feeder Pro", price: 129.99, stock: 45, isActive: true },
  { name: "Smart Feeder Lite", price: 79.99, stock: 60, isActive: true },
  { name: "Pet Water Fountain", price: 89.99, stock: 32, isActive: true },
  { name: "Portable Travel Feeder", price: 149.99, stock: 18, isActive: true },
  { name: "Slow Feeder Bowl", price: 34.99, stock: 0, isActive: false },
  { name: "Stainless Steel Bowl Set", price: 49.99, stock: 85, isActive: true },
  { name: "Replacement Filters (6-pack)", price: 24.99, stock: 120, isActive: true },
  { name: "Elevated Feeding Station", price: 79.99, stock: 22, isActive: true },
];

export default async function AdminProductsPage() {
  const session = await auth();
  if (!session || session.user?.email !== "admin@petfeeder.com") redirect("/");

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900">''' + chr(128230) + ''' Products</h1>
      </div>
      <div className="flex flex-col md:flex-row gap-8">
        <aside className="w-full md:w-48 flex-shrink-0">
          <nav className="flex md:flex-col gap-2">
            <Link href="/admin" className="block px-3 py-2 rounded text-sm text-gray-600 hover:bg-gray-50">''' + chr(128202) + ''' Dashboard</Link>
            <Link href="/admin/products" className="block px-3 py-2 rounded text-sm bg-blue-50 text-blue-600 font-medium">''' + chr(128230) + ''' Products</Link>
            <Link href="/admin/orders" className="block px-3 py-2 rounded text-sm text-gray-600 hover:bg-gray-50">''' + chr(128722) + ''' Orders</Link>
          </nav>
        </aside>
        <div className="flex-1">
          <div className="bg-white border rounded-lg overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-gray-50">
                <tr>
                  <th className="text-left p-3 text-gray-600 font-medium">Name</th>
                  <th className="text-left p-3 text-gray-600 font-medium">Price</th>
                  <th className="text-left p-3 text-gray-600 font-medium">Stock</th>
                  <th className="text-left p-3 text-gray-600 font-medium">Status</th>
                </tr>
              </thead>
              <tbody>
                {demoProducts.map((p) => (
                  <tr key={p.name} className="border-t hover:bg-gray-50">
                    <td className="p-3 text-gray-900">{p.name}</td>
                    <td className="p-3 text-gray-700">$''' + "{p.price.toFixed(2)}" + '''</td>
                    <td className="p-3 text-gray-700">{p.stock}</td>
                    <td className="p-3">
''' + products_span_line + '''
                        {p.isActive ? "Active" : "Inactive"}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
'''

# ==================== ORDERS ====================
orders_span_line = '                      <span className={' + BT + 'px-2 py-0.5 rounded text-xs font-medium ' + '{statusColors[order.status] || "bg-gray-100 text-gray-600"}' + BT + '}>'

orders = '''import { auth } from "@/lib/auth";
import { redirect } from "next/navigation";
import Link from "next/link";

const demoOrders = [
  { id: "ORD-2026-001", date: "2026-07-04", customer: "john@example.com", total: 259.96, status: "paid", tracking: "" },
  { id: "ORD-2026-002", date: "2026-07-01", customer: "sarah@example.com", total: 89.99, status: "shipped", tracking: "TRACK123456" },
  { id: "ORD-2026-003", date: "2026-06-28", customer: "mike@example.com", total: 129.99, status: "delivered", tracking: "TRACK789012" },
];

const statusColors: Record<string, string> = {
  delivered: "bg-green-100 text-green-700",
  shipped: "bg-orange-100 text-orange-700",
  paid: "bg-blue-100 text-blue-700",
  pending: "bg-gray-100 text-gray-600",
  refunded: "bg-red-100 text-red-700",
};

export default async function AdminOrdersPage() {
  const session = await auth();
  if (!session || session.user?.email !== "admin@petfeeder.com") redirect("/");

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6 text-gray-900">''' + chr(128722) + ''' Orders</h1>
      <div className="flex flex-col md:flex-row gap-8">
        <aside className="w-full md:w-48 flex-shrink-0">
          <nav className="flex md:flex-col gap-2">
            <Link href="/admin" className="block px-3 py-2 rounded text-sm text-gray-600 hover:bg-gray-50">''' + chr(128202) + ''' Dashboard</Link>
            <Link href="/admin/products" className="block px-3 py-2 rounded text-sm text-gray-600 hover:bg-gray-50">''' + chr(128230) + ''' Products</Link>
            <Link href="/admin/orders" className="block px-3 py-2 rounded text-sm bg-blue-50 text-blue-600 font-medium">''' + chr(128722) + ''' Orders</Link>
          </nav>
        </aside>
        <div className="flex-1">
          <div className="bg-white border rounded-lg overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-gray-50">
                <tr>
                  <th className="text-left p-3 text-gray-600 font-medium">Order</th>
                  <th className="text-left p-3 text-gray-600 font-medium">Date</th>
                  <th className="text-left p-3 text-gray-600 font-medium">Customer</th>
                  <th className="text-left p-3 text-gray-600 font-medium">Total</th>
                  <th className="text-left p-3 text-gray-600 font-medium">Status</th>
                  <th className="text-left p-3 text-gray-600 font-medium">Tracking</th>
                </tr>
              </thead>
              <tbody>
                {demoOrders.map((order) => (
                  <tr key={order.id} className="border-t hover:bg-gray-50">
                    <td className="p-3 font-mono text-sm text-gray-900">{order.id}</td>
                    <td className="p-3 text-gray-600">{order.date}</td>
                    <td className="p-3 text-gray-600">{order.customer}</td>
                    <td className="p-3 text-gray-900">$''' + "{order.total.toFixed(2)}" + '''</td>
                    <td className="p-3">
''' + orders_span_line + '''
                        {order.status}
                      </span>
                    </td>
                    <td className="p-3 text-xs text-gray-500">{order.tracking || "''' + chr(8212) + '''"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
'''

# Write all files
with open(os.path.join(D, "page.tsx"), "w", encoding="utf-8") as f:
    f.write(dashboard)
    print("Dashboard written")

with open(os.path.join(D, "products", "page.tsx"), "w", encoding="utf-8") as f:
    f.write(products)
    print("Products written")

with open(os.path.join(D, "orders", "page.tsx"), "w", encoding="utf-8") as f:
    f.write(orders)
    print("Orders written")

print("Done!")
