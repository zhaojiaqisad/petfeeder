﻿import prisma from "../src/lib/db";

async function main() {
  console.log("Seeding database...");

  // Create categories
  const feeders = await prisma.category.upsert({
    where: { slug: "feeders" },
    update: {},
    create: {
      name: { en: "Automatic Feeders", de: "Automatische Futterspender", fr: "Distributeurs Automatiques" },
      slug: "feeders",
      sortOrder: 1,
    },
  });

  const fountains = await prisma.category.upsert({
    where: { slug: "fountains" },
    update: {},
    create: {
      name: { en: "Water Fountains", de: "Wasserbrunnen", fr: "Fontaines à Eau" },
      slug: "fountains",
      sortOrder: 2,
    },
  });

  const bowls = await prisma.category.upsert({
    where: { slug: "bowls" },
    update: {},
    create: {
      name: { en: "Bowls & Accessories", de: "Näpfe & Zubehör", fr: "Gamelles & Accessoires" },
      slug: "bowls",
      sortOrder: 3,
    },
  });

  console.log("Created categories:", { feeders: feeders.id, fountains: fountains.id, bowls: bowls.id });

  // Create products
  const products = [
    {
      name: { en: "Smart Feeder Pro", de: "Smart Feeder Pro", fr: "Smart Feeder Pro" },
      slug: "smart-feeder-pro",
      description: {
        en: "Programmable automatic feeder for cats and dogs. Holds up to 5L of dry food. WiFi connected, app controlled.",
        de: "Programmierbarer automatischer Futterspender für Katzen und Hunde. Fasst bis zu 5L Trockenfutter.",
        fr: "Distributeur automatique programmable pour chats et chiens. Jusqu'à 5L de nourriture sèche.",
      },
      basePrice: 129.99,
      prices: { USD: 129.99, EUR: 119.99, GBP: 102.99, AUD: 198.99 },
      images: ["https://placehold.co/400x400?text=Smart+Feeder+Pro"],
      categoryId: feeders.id,
      stock: 45,
      isActive: true,
      specifications: [
        { label: "Capacity", value: "5L" },
        { label: "Power", value: "AC adapter + battery backup" },
        { label: "Connectivity", value: "WiFi 2.4GHz" },
      ],
    },
    {
      name: { en: "Pet Water Fountain", de: "Haustier-Wasserbrunnen", fr: "Fontaine pour Animaux" },
      slug: "pet-water-fountain",
      description: {
        en: "Premium pet water fountain with 2.5L capacity. Triple filtration system ensures fresh, clean water.",
        de: "Premium Haustier-Wasserbrunnen mit 2,5L Fassungsvermögen.",
        fr: "Fontaine à eau premium pour animaux de compagnie. Capacité de 2,5L.",
      },
      basePrice: 89.99,
      prices: { USD: 89.99, EUR: 82.99, GBP: 70.99, AUD: 137.99 },
      images: ["https://placehold.co/400x400?text=Water+Fountain"],
      categoryId: fountains.id,
      stock: 32,
      isActive: true,
      specifications: [
        { label: "Capacity", value: "2.5L" },
        { label: "Filtration", value: "3-stage" },
        { label: "Noise Level", value: "< 25dB" },
      ],
    },
  ];

  for (const product of products) {
    await prisma.product.upsert({
      where: { slug: product.slug },
      update: product,
      create: product,
    });
  }

  console.log(`Seeded ${products.length} products`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
